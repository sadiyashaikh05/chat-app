# Real-Time Chat App 💬

A simple real-time chat application using **Node.js**, **Express**, and **Socket.IO**.

---

## 🛠 Technologies Used

- HTML, CSS
- JavaScript
- Node.js
- Express.js
- Socket.IO

---

## 🚀 How to Run

1. Open terminal and run:
   ```
   npm install
   node server.js
   ```
2. Visit: [http://localhost:3000](http://localhost:3000)

3. Open in two browser tabs and start chatting live!

---

## 📚 License

Made for internship/project use.
